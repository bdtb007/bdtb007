# -*- coding: utf-8 -*-
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver import Keys


import time
import random
import datetime 



headers = {
'user-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36',
}

options = webdriver.ChromeOptions()
options.add_experimental_option('detach',True)
browser = webdriver.Chrome()



web_url = 'https://tieba.baidu.com/index.html'
browser.get(web_url)

print('是否已登录百度贴吧账号')
choice = input('确认登陆后请安确认按钮')

if choice == 'n':
    print('请关闭预览器后，重新执行')


else:
    print('jll')
    while True:            
        try:
            # 评论的地址
            browser.get('')
            # 处理新窗口问题
            handles = browser.window_handles
            browser.switch_to.window(handles[-1])
            time.sleep(2)

            try:
                browser.find_elements('class name','j_quick_reply')[0].click()
            except:
                print('1')
                # browser.implicitly_wait(2)
                time.sleep(2)
                browser.find_elements('class name','j_quick_reply')[0].click()


            pl_time = datetime.datetime.now() 
            print(pl_time,'发送评论')
            time.sleep(1)
            try:
                browser.find_element('class name','edui-editor-body').click()
            except:
                # browser.implicitly_wait(1)
                time.sleep(2)
                browser.find_element('class name','edui-editor-body').click()
                print('2')


            try:
                browser.find_element('class name','edui-body-container').send_keys(str(pl_time))
            except:
                # browser.implicitly_wait(30)
                time.sleep(2)
                browser.find_element('class name','edui-body-container').send_keys(str(pl_time))
                print('内容进来的')

            try:
                browser.find_element('class name','edui-btn-emotion').click()
            except:
                time.sleep(2)
                browser.find_element('class name','edui-btn-emotion').click()
                print('点击表情进来')

            # 随机表情包
            try:
                random_element = random.choice(browser.find_elements('class name','s_face'))
                random_element.click()
                
            except:
                time.sleep(2)
                random_element = random.choice(browser.find_elements('class name','s_face'))
                random_element.click()
                print('选择表情进来')

            try:
                browser.find_element('class name','j_submit').click()
            except:
                time.sleep(2)
                print('@@@@====>')
                browser.find_element('class name','j_submit').send_keys(Keys.CONTROL,Keys.ENTER)
            time.sleep(1)
            
        except:
            print('外层报错')
            browser.refresh()
        time.sleep(360)

 
   
   


